## Cài đặt

- Cài Nodejs
- Cài Yarn

```bash
npm install -g yarn
```

- Cài Dependencies

```bash
yarn
```

- Chạy

```bash
yarn start
```
